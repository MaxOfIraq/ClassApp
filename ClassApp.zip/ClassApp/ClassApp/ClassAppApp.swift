//
//  ClassAppApp.swift
//  ClassApp
//
//  Created by احمد صلاح on 28/03/2024.
//

import SwiftUI
import Firebase
@main
struct ClassAppApp: App {
    @StateObject var authentication = Authentication()
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(authentication)
        }
    }
}


class Authentication : ObservableObject{
    @Published var isLoggedIn : Bool{
        didSet{
            UserDefaults.standard.set(isLoggedIn, forKey: "isLoggedIn")
        }
    }
    
    
    @Published var errorMessage : ErrorItem?
    
    init(){
        self.isLoggedIn = UserDefaults.standard.bool(forKey: "isLoggedIn")
    }
    
    
    func signIn(email: String, password: String){
        Auth.auth().signIn(withEmail: email, password: password){ authResult, error in
            if let error = error{
                self.errorMessage = ErrorItem(message: error.localizedDescription)
            }else{
                self.isLoggedIn = true
            }
        }
    }
    
    
    
    
    
    func signUp(email: String, password: String){
        Auth.auth().createUser(withEmail: email, password: password){ authResult, error in
            if let error = error{
                self.errorMessage = ErrorItem(message: error.localizedDescription)
            }else{
                self.isLoggedIn = true
            }
        }
    }
    
    
    
    func signOut(){
        do{
            try Auth.auth().signOut()
            self.isLoggedIn = false
        }catch let signOutError as NSError{
            print("the acount is signOut", signOutError)
        }
    }
}
