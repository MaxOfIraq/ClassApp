//
//  SettingsView.swift
//  ClassApp
//
//  Created by احمد صلاح on 31/03/2024.
//

import SwiftUI

struct SettingsView : View {
    @EnvironmentObject var authentication : Authentication
    var body: some View{
        List{
            Text("Settings")
                .font(.title)
                .padding()
            
            Button(action: signOut){
                Text("SignOut")
                    .foregroundColor(.red)
            }
        }
    }
    
    
    func signOut(){
        authentication.signOut()
    }
}
