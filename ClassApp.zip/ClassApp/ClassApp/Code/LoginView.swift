//
//  LoginView.swift
//  ClassApp
//
//  Created by احمد صلاح on 31/03/2024.
//

import SwiftUI

struct LoginView : View {
    
    @EnvironmentObject var authentication : Authentication
    @State private var email : String = ""
    @State private var password : String = ""
    
    var body: some View {
        NavigationView{
            VStack{
                Image("i")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 200)
                    .padding(.bottom, 30)
                
                
                TextField("Enter your Email Here", text: $email)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                SecureField("Enter your Password Here", text: $password)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                
                Button(action: signIn){
                   Text("Sign In To your Acount")
                
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .cornerRadius(10)
                .padding(.horizontal, 20)
                }
                Spacer()
                
                NavigationLink(destination: SignUpView()){
                    Text("Don't have an acount ? Sign Up")
                        .foregroundColor(.blue)
                        .padding(.top, 20)
                }
            }
        }
            
    }
    
    
    func signIn(){
        authentication.signIn(email: email, password: password)
    }
}
