//
//  SignUpView.swift
//  ClassApp
//
//  Created by احمد صلاح on 31/03/2024.
//



import SwiftUI

struct SignUpView : View {
    @EnvironmentObject var authentication : Authentication
    @State private var email : String = ""
    @State private var password : String = ""
    @State private var ConfirmPassword : String = ""
    var body: some View {
        NavigationView{
            VStack{
    
                TextField("Enter your Email Here", text: $email)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                SecureField("Enter your Password Here", text: $password)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                
                SecureField("Confirm your Password Here", text: $ConfirmPassword)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                
                Button(action: signIn){
                   Text("Sign In To your Acount")
                
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .cornerRadius(10)
                .padding(.horizontal, 20)
                }
            }
            .padding()
            .navigationBarTitle("Sign Up")
        }
            
    }
    
    
    func signIn(){
        authentication.signUp(email: email, password: password)
    }
}
