//
//  WelcomeView.swift
//  ClassApp
//
//  Created by احمد صلاح on 31/03/2024.
//

import SwiftUI

struct WelcomeView : View {
    @EnvironmentObject var authentication : Authentication
    var body: some View{
        TabView{
            
            Name1()
                .tabItem {
                    Image(systemName: "house")
                        Text("Home")
                }
                .tag(0)
            
            SettingsView()
                .tabItem {
                    Image(systemName: "gear")
                        Text("Settings")
                }
                .tag(1)
        }
    }
}




struct Name1 : View {
    var body: some View{
        Text("Name1")
    }
}
