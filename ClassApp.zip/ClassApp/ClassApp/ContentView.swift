//
//  ContentView.swift
//  ClassApp
//
//  Created by احمد صلاح on 28/03/2024.
//

import SwiftUI


struct ErrorItem : Identifiable{
    var id = UUID()
    var message : String
}

struct ContentView: View {
    @EnvironmentObject var authentication : Authentication
    var body: some View {
        if authentication.isLoggedIn{
            WelcomeView()
        }else {
            LoginView()
        }
    }
}

#Preview {
    ContentView()
}
